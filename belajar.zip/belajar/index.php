 <!DOCTYPE html>
<html>
<head>
<title >Page Title</title>
<script src="jquery-3.2.1.min.js"></script>
</head>
<body>
<div id="muncul">
<p>belajar jquery</p>
<hr>
<p>jquery mudah</p>
<hr>
<h4 id="bodoh">sentuh saya dengan lembut</h4>
</div>	
<hr>
<button id="hilang">hilang</button><br>
<button id="tampil">tampil</button><br>
<button id="ye">hilang buttton</button><br>
<button id="semua">tampil/hilang semua baik button atau text</button><br>
<button id="box">object tampil</button><br>
<div id="div1" style="width:100px;height:100px;display:none;background-color:red;"></div><br>
<div id="div2" style="width:100px;height:100px;display:none;background-color:green;"></div><br>
<div id="div3" style="width:100px;height:100px;display:none;background-color:blue;"></div>
<script>
$(document).ready(function(){
    $("#hilang").click(function(){        
         $("p").hide();
    });
    $("#tampil").click(function(){        
         $("p").show();
         $("h1").show();
    });
     $("#ok").click(function(){        
         $("h1").hide();
    });
      $("#ye").click(function(){        
         $("#hilang").hide(2000);
         $("#tampil").hide(3000);
          $("#ye").hide(4000);
          $("#semua").hide(6000);
          $("#box").hide(7000);
    });
      
       $("#semua").click(function(){
        $("#muncul").toggle();
		$("#ye").toggle();
		$("#hilang").toggle();
		$("#tampil").toggle(); 
		$("#div1").fadeToggle();
		$("#div2").fadeToggle();
		$("#div3").fadeToggle();        
    });
       $("#bodoh").mouseenter(function(){
          $("#hilang").show(2000);
         $("#tampil").show(3000);
          $("#ye").show(4000);
          $("#semua").show(6000);
          $("#box").show(7000);  
    });
       $("#box").click(function(){
        $("#div1").fadeIn();
        $("#div2").fadeIn("slow");
        $("#div3").fadeIn(3000);
    });
});
</script>
</body>
</html> 